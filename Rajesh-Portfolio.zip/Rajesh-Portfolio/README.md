# Rajesh S | Digital Marketing Executive Portfolio

A responsive, single-page portfolio website for Rajesh S, a Digital Marketing Executive based in Chennai, India (SEO, Meta Ads and lead generation).

Built with plain **HTML5, CSS3 and vanilla JavaScript**. No build tools, no frameworks, no installs. Fonts are Inter and Sora from Google Fonts, icons are inline SVG, and SEO data is added as JSON-LD.

## Project structure

```
Rajesh-Portfolio/
├── index.html              Page structure and content
├── css/
│   └── style.css           All styling, animations, themes and responsive rules
├── js/
│   └── script.js           All interactions (theme toggle, animations, tabs, calculator)
├── assets/
│   ├── images/
│   │   └── .gitkeep        Put your profile photo here as Portfolio.png
│   └── logos/
│       ├── maruthi-power-control-systems.png
│       ├── placement-point-solutions.png
│       └── why-global-services.png
└── README.md
```

## What each file does

**index.html** holds the content and these sections, in order: navigation, hero (`#home`), tools strip, About (`#about`), Skills (`#skills`), How I work (`#process`), Experience (`#experience`), Featured projects (`#work`), Lead estimator (`#calc`), Education (`#education`), Contact (`#contact`), footer and the floating WhatsApp button. The head contains the SEO title and description, Open Graph tags, the favicon and the JSON-LD structured data.

**css/style.css** contains every style. Colours are CSS variables at the top of the file (`:root`). Dark is the default theme, and a light theme applies through `prefers-color-scheme` and the theme button. It also includes the animations, the responsive breakpoints and the `prefers-reduced-motion` rules.

**js/script.js** has two parts, marked by comments:
1. Theme toggle, scroll progress bar, active navigation link, cursor spotlight, magnetic buttons, number counters, scroll-reveal, typewriter in the hero, and the lead estimator.
2. Skills category tabs (with arrow-key support) and the About "Read more" toggle.

**assets/logos/** holds the three company logos used in the Featured projects cards.

**assets/images/** is where your profile photo goes (see below).

## Run it locally

Option 1: double-click `index.html`. It opens in your browser.

Option 2: use a local server, which behaves like real hosting. From inside the project folder:

```
python3 -m http.server 8000
```

Then open http://localhost:8000. In VS Code you can also right-click `index.html` and choose "Open with Live Server".

Google Fonts need an internet connection. Without one, the page falls back to your system fonts.

## Add your profile photo

Save your photo as **`assets/images/Portfolio.png`** (same spelling and capital P). Until that file exists, the page shows an "RS" badge instead, so nothing is broken.

## Deploy on GitHub Pages (free)

1. Sign in at https://github.com and click **New repository**. Name it, for example, `rajesh-portfolio`, and set it to **Public**.
2. Upload the project contents so that `index.html` sits at the top level of the repository, with the `css`, `js` and `assets` folders beside it. On the repository page choose **Add file → Upload files**, drag the contents in (not the outer `Rajesh-Portfolio` folder itself), and click **Commit changes**. If you use Git, run `git add .`, `git commit`, then `git push`.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to **Deploy from a branch**. Choose branch **main** and folder **/ (root)**, then click **Save**.
5. Wait one to two minutes. Your site will be live at `https://YOUR-USERNAME.github.io/rajesh-portfolio/`.

To get the shorter address `https://YOUR-USERNAME.github.io/`, name the repository exactly `YOUR-USERNAME.github.io`.

All paths in this project are relative (for example `css/style.css` and `assets/logos/...`), so they work locally and on GitHub Pages without changes.

**GitHub Pages is case-sensitive.** `Portfolio.png` and `portfolio.png` are different files there, so keep the names exactly as shown above.

To update the live site later, upload the changed files again (or push with Git) and GitHub Pages redeploys automatically.

## Editing guide

| To change | Where |
|---|---|
| Colours | CSS variables in `:root` at the top of `css/style.css` |
| Name, text, experience, education | `index.html` |
| Contact email, phone, WhatsApp, LinkedIn | The Contact section and nav in `index.html`, plus `sameAs` in the JSON-LD in the head |
| Google Drive links | The three project cards and the "full portfolio folder" link in `#work` |
| Skill categories and items | The `S` array in `js/script.js` |
| Words in the hero typing effect | The `W` array in `js/script.js` |
| Company logos | Replace the files in `assets/logos/` (keep the same file names) |

## Things to know

- **Theme toggle and the dark background colour.** The theme button in `script.js` detects dark mode by comparing the `--bg` variable to the exact value `#0A1022`. If you ever change the dark `--bg` colour in `style.css`, update that value in `script.js` too, or the toggle will stop switching correctly.
- **Google Drive folders** must be shared as "Anyone with the link" for visitors to open them. Check before sharing the site, and remove customer names or phone numbers from anything you make public.
- **Favicon** is an inline SVG in the `<head>` of `index.html` and still uses the earlier blue colour. It can be changed later without affecting anything else.
- **Link previews.** No `og:image` is set yet, so WhatsApp and LinkedIn previews will not show a picture. Add one when you have a preview image.
- **Lead estimator** is a simple example calculator (budget divided by cost per lead). It does not show real campaign results.

## Backup

Keep a copy of the ZIP file, or the whole `Rajesh-Portfolio` folder, somewhere safe (for example Google Drive or an external drive).
